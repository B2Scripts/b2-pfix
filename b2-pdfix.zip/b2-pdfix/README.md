
```
## Requirements

qb-core - https://github.com/qbcore-framework/qb-core

polyzone - https://github.com/mkafrin/PolyZone
```

```
## supported areas
mrpd deparment
ems departmemt
davis department
apartments
```


```
## not to be sold or used in paid content!!
```
